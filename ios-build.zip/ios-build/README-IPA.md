# Build a real .IPA with GitHub Actions

This folder builds **ArenaAIChat.ipa** automatically on GitHub — no Mac needed to build.

## What this does
- GitHub's Mac runners compile the SwiftUI wrapper + your chat app
- Produces an **unsigned** `ArenaAIChat.ipa` (ready for Sideloadly / AltStore to sign)
- You download it from **Actions → Artifacts**

## Setup (one time, 5 minutes)

### Option A — Upload these files to your existing repo
In your GitHub repo, add these files (keep the same folders):
```
.github/workflows/build-ipa.yml
project.yml
ArenaAIChat/ArenaAIChatApp.swift
ArenaAIChat/Info.plist
ArenaAIChat/index.html
ArenaAIChat/icon.png
ArenaAIChat/Assets.xcassets/Contents.json
ArenaAIChat/Assets.xcassets/AppIcon.appiconset/Contents.json
```
How: Repo → **Add file → Upload files** → drag the files in (upload folder by folder), or **Create new file** and paste the text for `.yml` / `.yml` / `.swift` / `.plist` / `.json` files.

> Your repo must be **Public** for free Actions minutes (private repos get limited minutes). Your API keys are NOT in these files — they're stored on the phone only.

### Option B — New repo just for the IPA
Create a new public repo, upload everything in this `ios-build` folder to its root.

## Build
1. Push to `main` (or go to **Actions → Build IPA → Run workflow**)
2. Wait ~5-10 minutes for the green checkmark ✅
3. Click the run → scroll to **Artifacts** → download **ArenaAIChat-IPA** (zip containing the .ipa)

## Sideload the IPA onto your iPhone
1. On a Mac/PC, install **Sideloadly** (sideloadly.io)
2. Plug in your iPhone, drag `ArenaAIChat.ipa` into Sideloadly
3. Sign in with your Apple ID → Install
4. On iPhone: **Settings → General → VPN & Device Management** → Trust your Apple ID
5. Open **ArenaAI** — done! 🎉

> Free Apple ID sideloads expire after 7 days. Use **AltStore / SideStore** on the iPhone if you want auto-refresh, or just re-sideload weekly. For no-expiry, use the Add to Home Screen method instead.

## Change bundle ID (optional)
In `project.yml`, change `com.arenaai.chat` to your own unique ID (e.g. `com.yourname.arenaai`) before building.
